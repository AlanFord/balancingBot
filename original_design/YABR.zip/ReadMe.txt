Thank you for downloading the YABR software package. 

Current version: 1.0 May 21, 2017

Content:
YABR_hardware_test.ino
Balancing_robot_remote.ino
Balancing_robot.ino

yabr-frame_parts.pdf
yabr-schematic_remote.pdf
yabr-schematic_robot.pdf


Revision update:
=====================================================================================================================================================

Version 1.1 - June 6, 2016
In the schematic the fault output of the DRV8825 stepper controller was connected to +5V. The schamtic is corrected.
=====================================================================================================================================================

Version 1.0 - May 10, 2016
First release
The software is tested with Arduino IDE version 1.0.6 and 1.8.2
=====================================================================================================================================================
